		VideoIntensityAnalysis V1.0:

	This release is only compatible with Windows.
	It is highly recommended that you run this program from the command line.

	This program is designed to analyze a video file frame by frame, 
analyze each pixel of the frame, compare it to the corresponding pixel from
the previous frame, and generate a normalized measure of absolute difference
between the two frames. If the result is over 30, those two frames are different
enough to be marked as a scene change or visually intense event.
	The output is saved in a .csv file which can be loaded into most any 
program that handles spreadsheets.
	If the program has issues opening a video file, try converting it to a
different type of file. .mp4 files are always a good choice.

	IMPORTANT: In its current state, because of how long it takes to analyze
long video files, attempting to exit out of the save dialogue at the end will
not close the program. You either have to choose a save file name/location or
manually close the program.
	IMPORTANT: If not running the .jar file from the command line, the 
program will not display progress while analyzing a video file. It will silently
do that in the background until the save dialogue pops up once it is done. If run
from the command line, it will print the frame number each time it analyzes a frame.